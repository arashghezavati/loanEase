// App.js

import React from 'react';
import StudentList from './StudentList';

function App() {
  return (
    <div className="App">
     
    </div>
  );
}

export default App;
